function [H,Y,X,Cmean,Cstd] = MGSM_MULTISUR_bowtieSmooth(n2, n1, binsz,col,disp,ll)
% [H,Y,X,Cmean,Cstd] = MGSM_MULTISUR_bowtieSmooth(n2, n1, binsz,col,disp,ll)
% Plot joint-conditional histogram ("bowtie"), namely p(n2|n1)
% renormalized to the max for each value of 'n1' (a column in the plot) 
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%
% Adapted from older code by Odelia Schwartz
%

if(~exist('binsz'))
    binsz=51;
end
if(~exist('col'))
    col=[0 1 0];
end
if(~exist('disp'))
    disp=0;
end
if(~exist('ll'))
    ll = 8;
end

lw = 4;


[H,Y,X] = MGSM_MULTISUR_jhisto(n1, n2, binsz);
colmax = max(1,max(H));
H = H ./ (ones(size(H,1),1)*colmax);

h = mkGaussian(7,[1 0; 0 1]/1.5);
H = imfilter(H,h);

imagesc(X,Y,H,[0 1]); axis('xy'); axis('square'); axis tight; hold on
colormap('gray');

[Cmean, Cstd] = MGSM_MULTISUR_condMean(n1, n2, binsz);
% 
if(disp)
    if(isempty(X<0))
        [~, indmin] = min(abs(X));
        ind = indmin + [-round(binsz/ll):round(binsz/ll)];
        plot(X(ind),Cmean(ind),'-g','LineWidth',lw,'Color',col); hold on
        plot(X(ind),Cmean(ind)+Cstd(ind),'--g','LineWidth',lw,'Color',col);
        plot(X(ind),Cmean(ind)-Cstd(ind),'--g','LineWidth',lw,'Color',col);
    else
        ind = 2:round(1*binsz/2);
            plot(X(ind),Cmean(ind),'-g','LineWidth',lw,'Color',col); hold on
        plot(X(ind),Cmean(ind)+1*Cstd(ind),'--g','LineWidth',lw,'Color',col);
    end
end