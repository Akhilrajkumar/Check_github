function [C Ceq] = MGSM_MULTISUR_constraint_cs(S, Kcs, indc, inds,nbrs,indcov,obj)
%   [C Ceq] = MGSM_MULTISUR_constraint_cs(S, Kcs, indc, inds,nbrsred,indcov,obj)
%   Enforces spatial symmetry on the covariance matrices
%   (eg, left and right of the center should be equivalent for a group of vertical filters)
%
% INPUTS
%   'S': covariance matrice for the center+surround configuration, in one long vector
%   'Kcs': [#surrounds x 1] #filters in each center+surround group
%   'indc': [1 x Kc] indices of center units
%   'inds': [#surrounds x Ks(1)] indices of surround units
%   'nbrs': [#filters x 4], filters parameters {scale; orientation; y position; x position}
%          ***NOTE: y position is in 'image/matrix' coordinates; center = 0; up = negative; down = positive
%   'indcov': index of the center+surround group corresponding to 'S'
%   'obj': target values 
%
% OUTPUTS
%   'C': value of the inequality constraints 
%   'Ceq': value of the inequality constraints (always 0, not used, but required by 'fmincon') 
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%%

% nbrsred = repmat(nbrsred,2,1);
Scs = reshape(S,Kcs(indcov),Kcs(indcov));
COVcs = Scs*Scs';
MM = mean(diag(COVcs));
INDD = ([indc inds(indcov,:)]);
mainOri = nbrs(inds(indcov,1),2); % RCC added 2016.01.17 - Was treating diagonals for Binary MGSM incorrectly

if(mainOri/size(inds,1) == 1/2 || mainOri==0) % vertical and horizontal surrounds
    tmp1 = find(nbrs(INDD,4) > 0);
    tmp2 = find(nbrs(INDD,4) < 0);
    C(1) = abs(mean(diag(COVcs(tmp1,tmp1))) - mean(diag(COVcs(tmp2,tmp2)))) / MM - 0.05;
    tmp1 = find(nbrs(INDD,3) > 0);
    tmp2 = find(nbrs(INDD,3) < 0);
    C(2) = abs(mean(diag(COVcs(tmp1,tmp1))) - mean(diag(COVcs(tmp2,tmp2)))) / MM - 0.05;
else % diagonal surrounds
    Kc = numel(find(nbrs(:,3)==0 & nbrs(:,4)==0));
    rot = (mainOri)*pi/(Kc/2);
    tmp1 = find(-nbrs(INDD,3) > ceil(tan(pi/2-rot)*nbrs(INDD,4)));
    tmp2 = find(-nbrs(INDD,3) < floor(tan(pi/2-rot)*nbrs(INDD,4)));
    C(1) = abs(mean(diag(COVcs(tmp1,tmp1))) - mean(diag(COVcs(tmp2,tmp2)))) / MM - 0.05;
    tmp1 = find(-nbrs(INDD,3) > ceil(tan(-rot)*nbrs(INDD,4)));
    tmp2 = find(-nbrs(INDD,3) < floor(tan(-rot)*nbrs(INDD,4)));
    C(2) = abs(mean(diag(COVcs(tmp1,tmp1))) - mean(diag(COVcs(tmp2,tmp2)))) / MM - 0.05;
end

if size(inds,1)>1 % RCC added 2016.01.17 - Binary MGSM does not need this constraint
    if(numel(obj)==1)
        C(3) = abs(mean(abs(COVcs(:))) - obj) / obj;
    elseif(numel(obj)==2)
        Kc = numel(find(nbrs(:,3)==0 & nbrs(:,4)==0));
        C(3) = abs(mean(mean(abs(COVcs(1:Kc,1:Kc)))) - obj(1)) / obj(1);
        C(4) = abs(mean(mean(abs(COVcs((Kc+1):end,(Kc+1):end)))) - obj(2)) / obj(2);
    end
end
Ceq = 0;
    
end



