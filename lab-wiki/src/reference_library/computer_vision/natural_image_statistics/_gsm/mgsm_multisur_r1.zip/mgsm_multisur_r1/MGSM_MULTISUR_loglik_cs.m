function [LL DLL] = MGSM_MULTISUR_loglik_cs(S,data,Q,loga,Kcs,indcov,lambdacs,constcs,lPc,lPs,indc,inds,theeps)
%   [LL DLL] = MGSM_MULTISUR_loglik_cs(S,data,Q,loga,Kcs,indcov,lambdacs,constcs,lPc,lPs,indc,inds,theeps)
%   Expected Negative LogLikelihood (of the covriance matrix, given the current assignment) and its gradient, in the MGSM.
%
% INPUTS
%   'S': covariance matrice for the center+surround configuration, in one long vector
%   'data': [#samples x #filters]
%   'Q': [(1 + #surrounds) x #datapoints] posterior probability of the un-assigned component (first entry) 
%           and the assigned components for each surround group
%   'loga': [(1 + #surrounds) x 1] log-prior probability
%   'Kcs': [#surrounds x 1] #filters in each center+surround group
%   'indcov': index of the center+surround group corresponding to 'S'
%   'lambdacs': [#surround groups x #datapoints] covariance-weighted center+surround filters energy
%   'constcs': [#surround groups x 1] useful normalization constant to perform MGSM inference
%   'lPc': [1 x #datapoints] log-lik of the un-assigned center configuration
%   'lPs': [#surrounds x #datapoints] log-lik of the un-assigned surround configurations
%   'indc': [1 x Kc] indices of center units
%   'inds': [#surrounds x Ks(1)] indices of surround units
%   'theeps': small constant to prevent infinities in MGSM inference
%
% OUTPUTS
%   'LL': negative log-likelihood 
%   'DLL': vector of derivatives w.r.t. the entries of the covariance matrix 
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%% warning
if(any(isnan(S)))
    fprintf('\n\n NaN params from minimize to MGSM_MULTISUR_loglik_cs\n\n');
end

%% PARSE INPUTS
N = size(data,1);   % # of samples
NS = numel(loga)-1;    % # of surround groups

Scs = reshape(S,Kcs(indcov),Kcs(indcov));
COVcsn = Scs*Scs' ;
% INVCOVcsn = inv(COVcsn);
INVCOVcsn = COVcsn\eye(Kcs(indcov),Kcs(indcov)); % more stable numerically, much faster

%% COMPUTE LOGLIK 'LL'

l2pi = log(2*pi);
b2cs=NaN(NS,N);
lPcs=NaN(NS,N);
lP=NaN(NS+1,N);
QL=NaN(NS+1,N);

%************ note here we are updating the inputs 'constcs' and 'lambdacs' based on the new parameter values
%%%%%% minibatches of 100 to save 60% time
constcs(indcov) = (sqrt(det(INVCOVcsn)));
for m = 1:size(data,1)/100
    nn =((m-1)*100+1):m*100;
    lambdacs(indcov,nn) = sqrt(theeps + diag(data(nn,[indc inds(indcov,:)]) * INVCOVcsn * data(nn,[indc inds(indcov,:)])'));
end
%************ 

for i=1:NS
    b2cs(i,:) = besselk(-(Kcs(i)-2)/2 , lambdacs(i,:)) + eps;
end

for i=1:NS
    lPcs(i,:) = log(constcs(i)) + log(b2cs(i,:)) - ((Kcs(i)-2)/2)*log(lambdacs(i,:)) - (Kcs(i)/2)*l2pi;
end

lP(1,:) = lPc+nansum(lPs,1);
for i=1:NS
    inot = 1:NS;
    inot(inot==i)=[];
    lP(i+1,:) = lPcs(i,:) + nansum(lPs(inot,:),1);
end

for i=1:NS+1
    tmp = loga(i)+lP(i,:);
    QL(i,:) = Q(i,:).*tmp;
end

indno = (sum(~isfinite(QL),1)>0);
indn = 1:N;
indn(indno) = [];
if(sum(indno)>0)
    fprintf('%d nan or inf in MGSM_MULTISUR_loglik_cs \n',sum(indno));
end

QL(:,indno)=[];
LL = -squeeze(sum(mean(QL,2),1));

%% compute gradient 'DLL'
indcs = [indc inds(indcov,:)];

b1cs = besselk(-(Kcs(indcov))/2 , lambdacs(indcov,:) );
basecs = ( (Q(1+indcov,:).*b1cs)./(b2cs(indcov,:).*(lambdacs(indcov,:))) )'; basecs(indno)=[];
DLcs = - 0.5 * ( ((repmat(basecs,[1 Kcs(indcov)])'.*data(indn,indcs)')...
    *data(indn,indcs))/length(indn) - nanmean(Q(1+indcov,indn))*COVcsn);           % the matrix derivative of L wrt INVCOVcs
DLLcs = (INVCOVcsn'*DLcs*INVCOVcsn')*Scs + (INVCOVcsn*DLcs'*INVCOVcsn)*Scs; % the matrix derivative of L wrt S
DLLcs = -DLLcs;
DLLcs = reshape(DLLcs,Kcs(indcov)*Kcs(indcov),1);

DLL = -DLLcs;

end
