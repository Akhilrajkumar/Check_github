function [COVc,INVCOVc,COVs,INVCOVs,COVcs,INVCOVcs,passign,f] =  MGSM_MULTISUR_EM(nbrs,Kc,Ks,Kcs,indc,inds,data,name,numiter)
% [COVc,INVCOVc,COVs,INVCOVs,COVcs,INVCOVcs,passign,f] =  MGSM_MULTISUR_EM(nbrs,Kc,Ks,Kcs,indc,inds,data,name)
% Expectation-Maximization algorithm, learns the parameters of the MGSM (covariance matrices and prior assignment proability)
%
% INPUTS
%   'nbrs': [#filters x 4], filters parameters {scale; orientation; y position; x position}
%          ***NOTE: y position is in 'image/matrix' coordinates; center = 0; up = negative; down = positive
%   'Kc': #filters in the center
%   'Ks': [#surrounds x 1] #filters in each surround group
%   'Kcs': [#surrounds x 1] total #filters (center plus surround) in each group
%   'indc': [1 x Kc] indices of center units
%   'inds': [#surrounds x Ks(1)] indices of surround units
%   'data': [#samples x #filters]
%   'name': Optional. save results (after each EM iteration) to file with this name 
%   'numiter': Optional. Maximum number of EM iterations 
%
% OUTPUTS
%   'COVc': [Kc x Kc] learned covariance matrix between center filters
%   'INVCOVc': its inverse
%   'COVs': [#surrounds x Ks(1) x Ks(1)] learned covariance matrices
%           between surround filters, in each surround group
%   'INVCOVs': inverses
%   'COVcs': [#surrounds x Kcs(1) x Kcs(1)] learned covariance matrices
%           between all filters, in each center-surround group
%   'INVCOVcs': inverses
%   'passign': [#iterations x #surrounds+1] learned prior probability for
%   each MGSM component (1=center alone; 2=center with first surround group; etc)
%   'f': [#iterations x 1] objective function at each iteration (negative loglik, should decrease)
%
% NOTES
%   - This implementation assumes that #samples is a multiple of 100 (uses
%   minibatches of 100 for speed up).
%   - This implementation assumes that all surround groups have the same
%   number of filters, i.e. Ks(1)==Ks(2)==...==Ks(NS)
%   - For matrix inversion, we use invC = C\eye(size(C)) rather than inv(C)
%   because the former is much faster and numerically more stable.

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

if(~exist('name'))
    name='noname';
end
if(~exist('numiter'))
    numiter = 20;  % max # EM loops
end

if numel(unique(Ks))>1
    warning('All surround groups must have the same number of filters.')
    return
end

%% you might want to play with 'options' and 'numiter', to trade off speed and accuracy

%%% 'fmincon' options
options = optimset('Algorithm','active-set','GradObj','on','Display','off','TolFun',10^-3,'TolCon',10^-3,'MaxFunEvals',30000);

%%% tolerance for the convergence of EM
TolEM = 10^-3;

%%

%%% constants
theeps=10^-10;  % to avoid Inf and NaN
l2pi = log(2*pi);
N = size(data,1);
if mod(N,100)~=0
    warning('Number of data samples must be a multiple of 100.')
    return
end
NS=size(inds,1);

%%% initialize
passign=[];  % stores the probability that center and each of the surround groups share same mixer; grows at each iteration of EM
f=[];        % stores the value of the objective function; grows at each iteration of EM
COVcs = NaN(NS,Kcs(1),Kcs(1)); % covariance matrices
INVCOVcs = COVcs;
COVs = NaN(NS,Ks(1),Ks(1));
INVCOVs = COVs;
Scs = NaN(Kcs(1)^2,NS);
Ss = NaN(Ks(1)^2,NS);
nbrs2 = repmat(nbrs,2,1);

%% starting values

%%%%%%%%%%%%%%%%%%%%%%%%%% starting parameter values
a=ones(1,size(inds,1)+1)./(size(inds,1)+1); % prior assignment probability for each surround group
a(1) = 1-sum(a(2:end)); % probability that no surround group is assigned

for i=1:size(inds,1) % covariance matrices of latent gaussians
    tmp = cholcov(.5*cov(data(:,[indc inds(i,:)])))'+ (rand(Kcs(i)) - 0.5)*mean(var(data(:,[indc inds(i,:)])))/4; %start around sample covariance
    COVcs(i,:,:) = tmp*tmp';
    INVCOVcs(i,:,:) = (squeeze(COVcs(i,:,:)))\eye(Kcs(1)); 
    tmp = cholcov(.5*cov(data(:,[inds(i,:)])))'+ (rand(Ks(i)) - 0.5)*mean(var(data(:,[inds(i,:)])))/4; %start around sample covariance
    COVs(i,:,:) = tmp*tmp';
    INVCOVs(i,:,:) = (squeeze(COVs(i,:,:)))\eye(Ks(1)); 
end
Sc = cholcov(.5*cov(data(:,[indc])))'+ (rand(Kc) - 0.5)*mean(var(data(:,[indc])))/4; %start from sample covariance
COVc = Sc*Sc';
INVCOVc = COVc\eye(Kc); 

%% useful quantities for the minimization steps - will be updated during EM 

loga = log(a); loga(a==0)=log(eps);
lambdacs=NaN(NS,N); 
lambdas=NaN(NS,N); 
lambdac=NaN(1,N); 
constcs=NaN(NS,1);
consts=NaN(NS,1); 
constc = (sqrt(det(INVCOVc)));
for i=1:NS
    tmpINVCOVcs = squeeze(INVCOVcs(i,:,:));
    constcs(i) = (sqrt(det(tmpINVCOVcs)));
    tmpINVCOVs = squeeze(INVCOVs(i,:,:));
    consts(i) = (sqrt(det(tmpINVCOVs)));
    for m = 1:size(data,1)/100 %%%%%% minibatches of 100 to save 60% time
        n =((m-1)*100+1):m*100;
        lambdacs(i,n) = sqrt(theeps + diag(data(n,[indc inds(i,:)]) * tmpINVCOVcs * data(n,[indc inds(i,:)])'));
        lambdas(i,n) = sqrt(theeps + diag(data(n,[inds(i,:)]) * tmpINVCOVs * data(n,[inds(i,:)])'));
        if i==1
            lambdac(1,n) = sqrt(theeps + diag(data(n,indc) * INVCOVc * data(n,indc)'));
        end
    end
end

b2s=NaN(NS,N);
b2cs=NaN(NS,N);
lPs=NaN(NS,N);
lPcs=NaN(NS,N);
b2c = besselk(-(Kc-2)/2 , lambdac) + eps;
for i=1:NS
    b2s(i,:) = besselk(-(Ks(i)-2)/2 , lambdas(i,:)) + eps;
    b2cs(i,:) = besselk(-(Kcs(i)-2)/2 , lambdacs(i,:)) + eps;
end
lPc = log(constc) + log(b2c) - ((Kc-2)/2)*log(lambdac) - (Kc/2)*l2pi;
for i=1:NS
    lPcs(i,:) = log(constcs(i)) + log(b2cs(i,:)) - ((Kcs(i)-2)/2)*log(lambdacs(i,:)) - (Kcs(i)/2)*l2pi;
    lPs(i,:) = log(consts(i)) + log(b2s(i,:)) - ((Ks(i)-2)/2)*log(lambdas(i,:)) - (Ks(i)/2)*l2pi;
end

%% EM loop 
iter2=0; iter=0;
converged=0;
previous_f=-Inf;
while(~converged && iter<numiter)
    iter=iter+1;
    fprintf('\n'); fprintf('EM iteration %d started \n',iter);
    tic
    
    %%%%%%%%%%%%%%%%%%%%%%% we work on the cholesky decomposition of the covariance matrix, to ensure positive definite covariances
    for i=1:size(inds,1)
        Scs(:,i) = reshape(cholcov(squeeze(COVcs(i,:,:)))',Kcs(i)^2,1);
        Ss(:,i) = reshape(cholcov(squeeze(COVs(i,:,:)))',Ks(i)^2,1);
    end
    Sc =  reshape(cholcov(COVc)',Kc*Kc,1);
    
    %%%%%%%%%%%%%%%%%%%%%%% E-STEP 0
    Q = MGSM_MULTISUR_posteriorAssign(loga,lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs); % compute initial assignments
    
    %%%%%%%%%%%%%%%%%%%%%%% M-STEP 0 for the assignment probability - this is analytical
    iter2=iter2+1;
    for i=1:size(inds,1)+1
        a(i) = nanmean(Q(i,isfinite(Q(i,:)))); % update prior assignment probabilities
    end
    a=a./sum(a); % make sure they still sum to 1
    passign(iter,:) = a;
    loga = log(a); loga(a==0)=log(eps); %******* needed in the next E and M steps
    f(iter2)=MGSM_MULTISUR_loglik(data,Q,loga,Kc,Ks,Kcs,lambdac,constc,lambdas,consts,lambdacs,constcs); % compute new loglik
    fprintf('After partial M-step, negative log-likelihood is %d \n',f(iter2));

    %%%%%%%%%%%%%%%%%%%%%%% E-STEP 1
    Q = MGSM_MULTISUR_posteriorAssign(loga,lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs); % update assignments based on the new prior
                                        
    %%%%%%%%%%%%%%%%%%%%%%% M-STEP 1 for COVc and COVs - ie, the case where center and surround are not together
    iter2=iter2+1;
    
    startguess = Sc;
    for i=1:size(inds,1)
        startguess = [startguess; Ss(:,i)];
    end
    [res, fX] = fmincon(@(S)MGSM_MULTISUR_loglik_c(S,data,Q,loga,Kc,Ks,lPcs,indc,inds,theeps),startguess,[],[],[],[],[],[],@(S)MGSM_MULTISUR_constraint_c(S,Kc,Ks,inds,nbrs2),options);
    
    if(size(fX,1)>=1 && isreal(fX(end)) && isfinite(fX(end)))
        f(iter2)=(fX(end));
        res_c = reshape(res(1:Kc*Kc),Kc,Kc);
        COVc = res_c*res_c';
        INVCOVc = COVc\eye(Kc,Kc); 
        res_s = reshape(res(Kc*Kc+(1:Ks(1)*Ks(1))),Ks(1),Ks(1));
        tmp = res_s*res_s';
        COVs(1,:,:) = tmp;
        INVCOVs(1,:,:) = tmp\eye(Ks(1),Ks(1));
        
        for i=2:size(inds,1)
            res_s = reshape(res(Kc*Kc+sum(Ks(1:i-1).^2)+(1:Ks(i)*Ks(i))),Ks(i),Ks(i));
            tmp = res_s*res_s';
            COVs(i,:,:) = tmp;
            INVCOVs(i,:,:) = tmp\eye(Ks(i),Ks(i)); 
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%% useful quantities for the next E and M steps
        constc = (sqrt(det(INVCOVc)));
        for i=1:NS
            tmpINVCOVs = squeeze(INVCOVs(i,:,:));
            consts(i) = (sqrt(det(tmpINVCOVs)));
            for m = 1:size(data,1)/100  %%%%%% minibatches of 100 to save 60% time
                n =((m-1)*100+1):m*100;
                lambdas(i,n) = sqrt(theeps + diag(data(n,[inds(i,:)]) * tmpINVCOVs * data(n,[inds(i,:)])'));
                if i==1
                    lambdac(1,n) = sqrt(theeps + diag(data(n,indc) * INVCOVc * data(n,indc)'));
                end
            end
        end
        b2c = besselk(-(Kc-2)/2 , lambdac) + eps;
        for i=1:NS
            b2s(i,:) = besselk(-(Ks(i)-2)/2 , lambdas(i,:)) + eps;
        end
        lPc = log(constc) + log(b2c) - ((Kc-2)/2)*log(lambdac) - (Kc/2)*l2pi;
        for i=1:NS
            lPs(i,:) = log(consts(i)) + log(b2s(i,:)) - ((Ks(i)-2)/2)*log(lambdas(i,:)) - (Ks(i)/2)*l2pi;
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%% ************************

    fprintf('After partial M-step, negative log-likelihood is %d \n',f(iter2));
    else %%%%%%%%%****** if fmincon returned inf or nan, try perturbing the starting value for the next iteration
        fprintf(' **** warning: fmincon returned NaN or Inf \n\n');
        f(iter2)=NaN;
        for i=1:size(inds,1)
                    Ss(:,i) = reshape(cholcov(squeeze(COVs(i,:,:)))'+ (rand(Ks(i)) - 0.5)*mean(diag(squeeze(COVs(i,:,:))))/10,Ks(i)^2,1); % perturb slightly after each iteration
        end
        Sc =  reshape(cholcov(COVc)'+ (rand(Kc) - 0.5)*mean(diag(COVc))/10,Kc*Kc,1); % perturb slightly after each iteration
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    for n=1:size(inds,1)
        obj(1) = mean(abs(COVc(:))); % target values for the constraint function
        obj(2) = mean(abs(COVs(n,:))); % target values for the constraint function
        
        %%%%%%%%%%%%%%%%%%%%%%% E-STEPS 2:N for COVcs; ie, the cases where center and one of the surrounds are together
        Q = MGSM_MULTISUR_posteriorAssign(loga,lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs);
        
        %%%%%%%%%%%%%%%%%%%%%%% M-STEPS 2:N for COVcs
        iter2=iter2+1;
        
        startguess = Scs(:,n);
        [res, fX] = fmincon(@(S)MGSM_MULTISUR_loglik_cs(S,data,Q,loga,Kcs,n,lambdacs,constcs,lPc,lPs,indc,inds,theeps),startguess,[],[],[],[],[],[],@(S)MGSM_MULTISUR_constraint_cs(S,Kcs,indc,inds,nbrs2,n,obj),options);
                                                        
        if(size(fX,1)>=1 && isreal(fX(end)) && isfinite(fX(end)))
            f(iter2)=fX(end);
            res_cs = reshape(res(1:Kcs(n)*Kcs(n)),Kcs(n),Kcs(n));
            tmp = res_cs*res_cs';
            COVcs(n,:,:) = tmp;
            INVCOVcs(n,:,:) = tmp\eye(Kcs(n),Kcs(n));
            
            %%%%%%%%%%%%%%%%%%%%%%%%%% useful quantities for the next minimization steps
            tmpINVCOVcs = squeeze(INVCOVcs(n,:,:));
            constcs(n) = (sqrt(det(tmpINVCOVcs)));
            for m = 1:size(data,1)/100 %%%%%% minibatches of 100 to save 60% time
                nn =((m-1)*100+1):m*100;
                lambdacs(n,nn) = sqrt(theeps + diag(data(nn,[indc inds(n,:)]) * tmpINVCOVcs * data(nn,[indc inds(n,:)])'));
            end
            b2cs(n,:) = besselk(-(Kcs(n)-2)/2 , lambdacs(n,:)) + eps;
            lPcs(n,:) = log(constcs(n)) + log(b2cs(n,:)) - ((Kcs(n)-2)/2)*log(lambdacs(n,:)) - (Kcs(n)/2)*l2pi;
            
            fprintf('After partial M-step, negative log-likelihood is %d \n',f(iter2));
        else %%%%%%%%%****** if fmincon returned inf or nan, try perturbing the starting value for the next iteration
            fprintf(' **** warning: fmincon returned NaN or Inf \n\n');
            f(iter2)=NaN;
            Scs(:,n) = reshape(cholcov(squeeze(COVcs(n,:,:)))'+ (rand(Kcs(i)) - 0.5)*mean(diag(squeeze(COVcs(n,:,:))))/10,Kcs(n)^2,1); % perturb slightly after each iteration
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('Negative log-likelihood is now %d \n',f(iter2));

    %%%%%%%%%%%%%%%%%%%%%%% save after each iteration
    save( name, 'COVcs', 'INVCOVcs','COVc', 'INVCOVc', 'COVs', 'INVCOVs', ...
        'passign', 'f', 'data', 'indc', 'inds', 'Kc', 'Ks', 'Kcs', 'theeps')
    if(~isnan(f(iter2)))
        converged = MGSM_MULTISUR_EM_converged(-f(iter2),previous_f,TolEM);
        previous_f= -f(iter2);
    end
    
    fprintf('EM iteration %d completed \n',iter);
    toc
end

%%
end