function [N, Y, X] =  MGSM_MULTISUR_jhisto(Yim, Xim, nbins)
% [N, Y, X] = MGSM_MULTISUR_jhisto(YIMAGE, XIMAGE, NBINS_OR_BINSIZE)
% Compute joint histogram of Yimage and Ximage.
%
% NBINS_OR_BINSIZE (optional, default = 101) specifies either
% the number of histogram bins, or the negative of the binsize.
% It can be a [Y,X] 2-vector or it can be a scalar.
%

% 2015 Ruben Coen-Cagli 
% Adapted from Eero Simoncelli, Spring 97.

if (exist('nbins') == 1) 
  nbins = abs(round(nbins));
  if (prod(size(nbins)) == 1)
    nbins = [nbins,nbins];
  else
    nbins = nbins(:);
  end
else
  nbins = [101, 101]';
end

nbins=nbins-1;
[Xmn, Xmx] = range2(Xim);
X = Xmn + (Xmx-Xmn)*[0:nbins(2)]/nbins(2);
[Ymn, Ymx] = range2(Yim);
Y = Ymn + (Ymx-Ymn)*[0:nbins(1)]/nbins(1);
Ybs = (Y(2)-Y(1))/2;
nbins=nbins+1;
N = zeros(nbins);
for yind=1:nbins(1)
  ind1 = find(Yim > (Y(yind)-Ybs));
  ind2 = find(Yim(ind1) < (Y(yind)+Ybs));
  ind = ind1(ind2);
  if(size(ind,2)>0)
    N(yind,:) = hist(Xim(ind),X);
  end
end


