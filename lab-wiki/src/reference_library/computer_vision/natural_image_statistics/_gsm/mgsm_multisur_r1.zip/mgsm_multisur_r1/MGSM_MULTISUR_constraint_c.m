function [C Ceq] = MGSM_MULTISUR_constraint_c(S,Kc,Ks,inds,nbrs)
%   [C Ceq] = MGSM_MULTISUR_constraint_c(S, Kcs, indc, inds,nbrsred,indcov,obj)
%   Enforces spatial symmetry on the covariance matrices
%   (eg, left and right of the center should be equivalent for a group of vertical filters)
%
% INPUTS
%   'S': covariance matrice for the center+surround configuration, in one long vector
%   'Kc': #filters in the center
%   'Ks': [#surrounds x 1] #filters in each surround group
%   'inds': [#surrounds x Ks(1)] indices of surround units
%   'nbrs': [#filters x 4], filters parameters {scale; orientation; y position; x position}
%          ***NOTE: y position is in 'image/matrix' coordinates; center = 0; up = negative; down = positive
%
% OUTPUTS
%   'C': value of the inequality constraints 
%   'Ceq': value of the inequality constraints (always 0, not used, but required by 'fmincon') 
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%


%%
C = zeros(1,2*size(inds,1) + Kc/4);

Sc = reshape(S(1:Kc*Kc),Kc,Kc);
COVc = Sc*Sc';
MM = mean(diag(COVc));
if size(inds,1)>1 % RCC added 2016.01.17 - Binary MGSM does not need this constraint
    for i=1:Kc/4
        C(2*size(inds,1)+i) = abs(mean(diag(COVc([i i+Kc/2],[i i+Kc/2]))) - mean(diag(COVc(Kc/4+[i i+Kc/2],Kc/4+[i i+Kc/2])))) / MM;
    end
end


for i = 1:size(inds,1)
    if(i==1)
        Ss = reshape(S(Kc*Kc+(1:Ks(i)^2)),Ks(i),Ks(i));
    else
        Ss = reshape(S(Kc*Kc+sum(Ks(1:i-1).^2)+(1:Ks(i)^2)),Ks(i),Ks(i));
    end
    COVs = Ss*Ss';
    MM = mean(diag(COVs));
    INDD = inds(i,:);
    mainOri = nbrs(inds(i,1),2); % RCC added 2016.01.17 - Was treating diagonals for Binary MGSM incorrectly

    if(mainOri/size(inds,1) == 1/2 || mainOri==0) % vertical or horizontal surround group
        tmp1 = find(nbrs(INDD,4) > 0);
        tmp2 = find(nbrs(INDD,4) < 0);
        C(i) = abs(mean(diag(COVs(tmp1,tmp1))) - mean(diag(COVs(tmp2,tmp2)))) / MM - 0.05;
        tmp1 = find(nbrs(INDD,3) > 0);
        tmp2 = find(nbrs(INDD,3) < 0);
        C(i+size(inds,1)) = abs(mean(diag(COVs(tmp1,tmp1))) - mean(diag(COVs(tmp2,tmp2)))) / MM - 0.05;
    else
        rot = mainOri*pi/(Kc/2);
        tmp1 = find(-nbrs(INDD,3) > ceil(tan(pi/2-rot)*nbrs(INDD,4)));
        tmp2 = find(-nbrs(INDD,3) < floor(tan(pi/2-rot)*nbrs(INDD,4)));
        C(i) = abs(mean(diag(COVs(tmp1,tmp1))) - mean(diag(COVs(tmp2,tmp2)))) / MM - 0.05; 
        tmp1 = find(-nbrs(INDD,3) > ceil(tan(-rot)*nbrs(INDD,4)));
        tmp2 = find(-nbrs(INDD,3) < floor(tan(-rot)*nbrs(INDD,4)));
        C(i+size(inds,1)) = abs(mean(diag(COVs(tmp1,tmp1))) - mean(diag(COVs(tmp2,tmp2)))) / MM - 0.05;
    end
            
end

Ceq = 0;

end











