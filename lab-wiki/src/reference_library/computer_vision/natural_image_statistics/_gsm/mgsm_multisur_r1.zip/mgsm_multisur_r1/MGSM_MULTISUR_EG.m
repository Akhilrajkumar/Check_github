function [EG EGcomponents]  = MGSM_MULTISUR_EG(data,Q,lambdac,lambdacs,Kc,Kcs,indc)
% [EG EGcomponents]  = MGSM_MULTISUR_EG(data,Q,lambdac,lambdacs,Kc,Kcs,indc)
% Compute posterior inference of the Gaussian latent variables in the MGSM
%
% INPUTS
%   'data': [#samples x #filters]
%   'Q': [(1 + #surrounds) x #datapoints] posterior probability of the
%           un-assigned component (first entry) and the assigned components for each surround group
%   'lambdac': [1 x #datapoints] covariance-weighted center filters energy
%   'lambdacs': [#surround groups x #datapoints] covariance-weighted center+surround filters energy
%   'Kc': #filters in the center
%   'Kcs': [#surrounds x 1] total #filters (center plus surround) in each group
%   'indc': [1 x Kc] indices of center units
%
% OUTPUTS
%   'EG': [Kc x #datapoints] posterior mean of the Gaussian latents corrensponding to the center filters
%   'EGcomponents': [Kc x (1 + #surrounds) x #datapoints] conditional posterior means of the Gaussian latents
%   corrensponding to the center filters, for each assignment configuration (i.e. before weighting by the posterior assignment)
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%%
[NS, N] = size(lambdacs);

b1c = besselk(-(Kc)/2 , lambdac);
b2c = besselk(-(Kc-2)/2 , lambdac);
b1cs=NaN(NS,N);
b2cs=NaN(NS,N);
for i=1:NS
    b1cs(i,:) = besselk(-Kcs(i)/2 , lambdacs(i,:) );
    b2cs(i,:) = besselk(-(Kcs(i)-2)/2 , lambdacs(i,:));
end

EGcomponents = zeros(Kc,NS+1,N);
for i=1:Kc
    numi = ( sign(data(:,indc(i))) .* abs(data(:,indc(i))) )';
    EGcomponents(i,1,:) = (numi .* b1c) ./ ((lambdac.^.5)  .* b2c);
    for ns=1:NS
        EGcomponents(i,1+ns,:) = (numi .* b1cs(ns,:)) ./ ((lambdacs(ns,:).^.5)  .* b2cs(ns,:));
    end
end

maxEGcomponents = max(abs(EGcomponents),[],3);
EG = zeros(Kc,N);
for k=1:Kc
    EG(k,:) = nansum ( Q .* squeeze(EGcomponents(k,:,:)) ./ repmat(maxEGcomponents(k,:)',1,N) , 1 );
end



