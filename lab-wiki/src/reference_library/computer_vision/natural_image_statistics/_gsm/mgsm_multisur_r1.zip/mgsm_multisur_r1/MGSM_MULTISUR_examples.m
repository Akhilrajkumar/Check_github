%%
% This script illustrates how to build and train the MGSM.
% Complete implementations are provided for two example MGSMs (different number of surround groups), in 'MGSM_MULTISUR_reduceNbrs.m'. 
% The training code in 'MGSM_MULTISUR_EM.m' is general, and can be used with any number of surround groups.
% (However, training uses constrained optimization, and the constraint functions should be hand-tuned for specific surround choices)
% 
% There are three main blocks of code:
% - Data collection:
%       Read in images, build the steerable pyramid, collect and format filters' outputs needed for the MGSM.  
%       This block uses 'MGSM_MULTISUR_getNbrs.m' and 'MGSM_MULTISUR_reduceNbrs.m'
%
% - Training:
%       Train the MGSM using Expectation Maximization.
%       This block relies on 'MGSM_MULTISUR_EM.m'. 
%
% - Plots: 
%       Just the basics here: check that the iterations converged, and that the results look good (marginals are Gaussian and the bowtie dependency has been removed). 
%
% NOTE: you will need the following toolboxes
% - Matlab's optimization toolbox (the training algorithm in MGSM_MULTISUR_EM.m uses 'fmincon') 
% - Matlab's stats toolbox (for things like nanmean etc)
% - Matlab's image processing toolbox (used in the data collection phase, MGSM_MULTISUR_getNbrs.m uses 'imrotate', and for plotting the bowtie)
% - Eero Simoncelli's steerable pyramid toolbox: http://www.cns.nyu.edu/~eero/steerpyr/ (used only in the data collection phase)
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%%
%% COLLECT AND FORMAT DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% set up %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nsamp = 25000; % desired # of image patches for training
thenbrs = 'orisCircle'; % specifies arrangement of filters for center and surround, input to 'MGSM_MULTISUR_getNbrs'
whichMGSM = 'Binary'; %'5MGSM'; % which type of MGSM do we want to implement? Input to 'MGSM_MULTISUR_reduceNbrs'
imset = 'imagesRot'; % specify image pre-processing, input to 'MGSM_MULTISUR_getNbrs' 
if strcmp(whichMGSM,'Binary')
    mainOri = 0; % for the binary MGSM, orientation of the surround group (0=90deg, 1=45deg, etc)
    filename = strcat('TrainingSet',whichMGSM,'_mainOri',num2str(mainOri)); % save training data (filters' outputs) to 'filename'
    name=strcat('TrainingResults',whichMGSM,'_mainOri',num2str(mainOri));  % save training results (at each EM iteration) to 'name'
elseif strcmp(whichMGSM,'5MGSM')
    mainOri = 0; % not used really for the 5MGSM
    filename = strcat('TrainingSet',whichMGSM); % save filters' outputs to this file
    name=strcat('TrainingResults',whichMGSM);  % save training results (at each EM iteration) to 'name'
end

%%%%%%%%% read in images %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 'images' should be a 2D array, [#pixels #pixels], or 3D array, [#images #pixels #pixels]
Npix=256;
images = NaN(5,Npix,Npix);
im1=double(pgmRead('einstein.pgm')); 
im2=double(pgmRead('goldhill.pgm')); 
im3=double(pgmRead('crowd.pgm')); 
im4=double(pgmRead('boats.pgm')); 
im5=double(pgmRead('mountain.pgm')); 
images(1,:,:)=im1(floor(end/2)+[-Npix/2+1:Npix/2],floor(end/2)+[-Npix/2+1:Npix/2]);
images(2,:,:)=im2(floor(end/2)+[-Npix/2+1:Npix/2],floor(end/2)+[-Npix/2+1:Npix/2]);
images(3,:,:)=im3(floor(end/2)+[-Npix/2+1:Npix/2],floor(end/2)+[-Npix/2+1:Npix/2]);
images(4,:,:)=im4(floor(end/2)+[-Npix/2+1:Npix/2],floor(end/2)+[-Npix/2+1:Npix/2]);
images(5,:,:)=im5(floor(end/2)+[-Npix/2+1:Npix/2],floor(end/2)+[-Npix/2+1:Npix/2]);

%%%%%%%%% collect filters outputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%*** can take a minute or two, depending on Nsamp
pyr_params = struct;
pyr_params.oris = 8; % how many orientations in the pyramid
pyr_params.height = 1; % how many spatial scales in the pyramid
pyr_params.lev = 1; % which level of the pyramid are we collecting data from?
pyr_params.twid = 1; % transition width of the Fourier transform of the filters - controls size and s.f. tuning
surr_pos = 12; % surround diameter, in pixels
[nbrs, data] = MGSM_MULTISUR_getNbrs(imset, thenbrs, Nsamp,images,pyr_params,surr_pos);
%*** nbrs(i,2) is orientation of ith filter; 0=90deg, 1=45deg, etc

%%%%%%%%% subsample/format filters outputs for desired MGSM type %%%%%%%%%%
[data, nbrsred, Kc, Ks, Kcs, indc, inds]= MGSM_MULTISUR_reduceNbrs(data,nbrs,whichMGSM,surr_pos,mainOri);

%%%%%%%%% save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
save(filename,'thenbrs','imset','nbrsred','data','pyr_params','surr_pos','K*','indc','inds','whichMGSM','mainOri');

%%
%% RUN EM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% load %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load(filename)

%%%%%%%%% rescale data for numerical stability - this is empirical %%%%%%%%
factor = sqrt(.1 / var(data(:,indc(1+mainOri))));
data = factor*data;

%%%%%%%%% training %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%*** can take a minute or two per iteration, depending on Nsamp and whichMGSM
numiter = 20; % max number of EM iterations
[COVc,INVCOVc,COVs,INVCOVs,COVcs,INVCOVcs,passign,f] = MGSM_MULTISUR_EM(nbrsred,Kc,Ks,Kcs,indc,inds,data,name,numiter); % run EM training anlgorithm

%%%%%%%% compute useful quantities %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a= passign(end,:); % learned prior assignment probability, after last EM iteration
[lambdac,constc,lambdas,consts,lambdacs,constcs] = MGSM_MULTISUR_lambda(data,INVCOVc,INVCOVs,INVCOVcs,indc,inds); % generalized filters' energy
Q = MGSM_MULTISUR_posteriorAssign(log(a),lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs); % posterior assignment probabilities 
EG  = MGSM_MULTISUR_EG(data,Q,lambdac,lambdacs,Kc,Kcs,indc); % posterior mean of the latent gaussian variables for the center ('simple cell' responses)


%%
%% PLOTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% load %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load(filename)
load(name)

%%%%%%%%% check convergence ('f'=negative loglik, should decrease) %%%%%%%%
figure
plot(f,'-s'); hold on
xlabel('EM Iteration','FontSize',18); ylabel('Negative LogLik','FontSize',20);

%%%%%%%% check stats: marginal should be Gaussian %%%%%%%%%%%%%%%%%%%%%%%%%
theeps=10^-10;
N = size(data,1);
a= passign(end,:);
[lambdac,constc,lambdas,consts,lambdacs,constcs] = MGSM_MULTISUR_lambda(data,INVCOVc,INVCOVs,INVCOVcs,indc,inds,theeps);
Q = MGSM_MULTISUR_posteriorAssign(log(a),lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs);
EG  = MGSM_MULTISUR_EG(data,Q,lambdac,lambdacs,Kc,Kcs,indc);

unit1=mainOri+1;
unit2=1+mod(mainOri+2,4);
EG1 = EG(unit1,:); % unit with vertical orientation, position=center, phase 1
EG2 = EG(unit2,:); % unit with horizontal orientation, position=center, phase 1
nbins=50; 
xl=max(EG1);
maxD = max(abs(EG1))/max(abs(data(:,indc(unit1))));
data_gauss = randn(N*5,1)* nanstd(EG1);
figure; hold on;
Xind=ceil(nbins/8):nbins-floor(nbins/8);
[H,X]=(hist(maxD*data(:,indc(unit1)),[-xl:2*xl/nbins:xl])); 
H(H==0) = 1;
plot(X(Xind),log((H(Xind))./sum(H(Xind))),'k','LineWidth',4);
[H,X]=(hist(data_gauss(:),[-xl:2*xl/nbins:xl])); 
plot(X(Xind),log((H(Xind))./sum(H(Xind))),'--r','LineWidth',4);
[H,X]=(hist(EG1,[-xl:2*xl/nbins:xl])); 
plot(X(Xind),log((H(Xind))./sum(H(Xind))),'b','LineWidth',6);
legend('Data','Matched Gaussian','EG')
axis square; grid on; ylabel('Log(probability)','Fontsize',20);
set(gca,'XLim',[-1 1],'YLim',[-10 0]);

%%%%%%%% check stats: bowtie dependency has been removed %%%%%%%%%%%%%%%%%%
maxD2 = max(abs(EG2))/max(abs(data(:,indc(unit2))));
lims = [-.5 .5];
tix = [lims(1) 0 lims(2)];
figure; 
subplot(1,2,1); hold on; axis square; axis tight
MGSM_MULTISUR_bowtieSmooth([lims'; maxD2*data(:,indc(unit2))],[lims'; maxD*data(:,indc(unit1))],1.5*nbins,[0 1 0],0,1);
set(gca,'FontSize',30,'XLim',lims,'YLim',lims,'XTick',tix,'YTick',tix);
subplot(1,2,2);  hold on; axis square; axis tight
MGSM_MULTISUR_bowtieSmooth([lims'; EG2'],[lims'; EG1'],nbins,[0 1 0],0,1);
set(gca,'FontSize',30,'XLim',lims,'YLim',lims,'XTick',tix,'YTick',tix);

%%%%%%%% check parameters: prior assignment probability %%%%%%%%%%%%%%%%%%%
figure
plot(passign); hold on; ylim([0 1]); hold on;
xlabel('EM Iteration','FontSize',18); ylabel('Prior probability','FontSize',20);

%%
%%%%%%%% check parameters: spatial organization of variance %%%%%%%%%%%%%%%
ph=0;
or=4;
indc1 = indc(1:numel(indc)/2);
inds1 = inds(or,1:size(inds,2)/2);
COVc1=COVc/max(diag(COVc));
COVs1=squeeze(COVs(or,:,:))/max(diag(squeeze(COVs(or,:,:))));
COVcs1=squeeze(COVcs(or,:,:))/max(diag(squeeze(COVcs(or,:,:))));
SZ = 12;

figure; 
Nori=(numel(indc)/2);
subplot(1,3,1); hold on;
title('COVc: Center alone');
for i=1:numel(indc1)
    ind = indc1(i);
    x = nbrsred(ind,4);
    y = -nbrsred(ind,3);
    phi = pi/2 - nbrsred(ind,2)*pi/Nori;
    plot([x+2*cos(phi) x+2*cos(pi+phi)],[y+2*sin(phi) y+2*sin(pi+phi)],'-k','LineWidth',SZ*COVc1(i+ph*Kc/2,i+ph*Kc/2));
end
axis square; xlim([-10 10]);ylim([-10 10]); 
subplot(1,3,2); hold on
title('COVs: Surround alone');
for i=1:numel(inds1)
    ind = inds1(i);
    x = nbrsred(ind,4);
    y = -nbrsred(ind,3);
    phi = pi/2 - nbrsred(ind,2)*pi/Nori;
    plot([x+2*cos(phi) x+2*cos(pi+phi)],[y+2*sin(phi) y+2*sin(pi+phi)],'-k','LineWidth',SZ*COVs1(i+ph*Ks(or)/2,i+ph*Ks(or)/2));
end
axis square; xlim([-10 10]);ylim([-10 10]); 
subplot(1,3,3); hold on
title('COVcs: Center + Surround');
for i=1:numel(indc1)
    ind = indc1(i);
    x = nbrsred(ind,4);
    y = -nbrsred(ind,3);
    phi = pi/2 - nbrsred(ind,2)*pi/Nori;
    plot([x+2*cos(phi) x+2*cos(pi+phi)],[y+2*sin(phi) y+2*sin(pi+phi)],'-k','LineWidth',SZ*COVcs1(i+ph*Kc/2,i+ph*Kc/2));
end
for i=1:numel(inds1)
    ind = inds1(i);
    x = nbrsred(ind,4);
    y = -nbrsred(ind,3);
    phi = pi/2 - nbrsred(ind,2)*pi/Nori;
    plot([x+2*cos(phi) x+2*cos(pi+phi)],[y+2*sin(phi) y+2*sin(pi+phi)],'-k','LineWidth',SZ*COVcs1(Kc+i+ph*Ks(or)/2,Kc+i+ph*Ks(or)/2));
end
axis square; xlim([-10 10]);ylim([-10 10]); 
