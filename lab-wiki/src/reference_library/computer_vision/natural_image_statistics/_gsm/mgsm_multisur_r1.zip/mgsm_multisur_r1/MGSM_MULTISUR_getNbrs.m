function [nbrs, l] = MGSM_MULTISUR_getNbrs(imset, thenbrs, Nsamp,images,pyr_params,surr_pos,rotIn)
% [nbrs, l] = MGSM_MULTISUR_getNbrs(imset, thenbrs, Nsamp,images,pyr_params,surr_pos)
% Define a neighborhood of filters, then collect their outputs at a 'Nsamp'
% locations across the image(s). 
%
% INPUTS
%   'imset': specifies type of image preprocessing
%   'thenbrs': specifies spatial neighborhood of filters
%   'Nsamp': how many samples we want to collect (set Nsamp=-1 to sample all positions in each image)
%   'images': [#images x #pixels x #pixels]
%   'pyr_params': matlab structure containing pyramid parameters
%         pyr_params.oris: how many orientations in the pyramid
%         pyr_params.height: how many spatial scales in the pyramid
%         pyr_params.lev: which level of the pyramid are we collecting data from?
%         pyr_params.twid: transition width of the Fourier transform of the filters - controls size and s.f. tuning
%   'surr_pos': optional, controls the extent of the surround
%   'rotIn': optional, by how many degrees we rotate the images
%
% OUTPUTS
%   'nbrs': [#filters x 4], filters parameters {scale; orientation; y position; x position}
%         ***NOTE: y position is in 'image/matrix' coordinates; center = 0; up = negative; down = positive
%   'l': [Nsamp x #filters], vectors of filters responses
%
% NOTES
%   - When imset=='imagesRot', this uses 'imrotate.m' from Matlab's "image processing toolbox"
%   - Requires Eero Simoncelli's "Steerable pyramid toolbox"

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%
% Adapted from older code by Odelia Schwartz
%


%%

if(~exist('surr_pos'))
    surr_pos=12;
end
if(~exist('rotIn'))
    rotIn=0;
end

pyr_oris = pyr_params.oris - 1; % how many orientations in the pyramid
pyr_height=pyr_params.height; % how many spatial scales in the pyramid
pyr_lev=pyr_params.lev; % reference pyramid level
pyr_twid=pyr_params.twid; % transition width of the Fourier transform of the filters - controls size and s.f. tuning

%%% add singleton dimension if there is only 1 image
if numel(size(images))==2
    tmpimages = NaN(1,size(images,1),size(images(2)));
    tmpimages(1,:,:) = images;
    images = tmpimages;
    clear tmpimages;
end
NIM = size(images,1);
NP = size(images,2);

%%% default choices for 'MGSM_MULTISUR_revised_makeSnbrs.m'
theOri=1;

%%% initialize
neighbors = [];

%%
switch thenbrs
    case('orisCircle')
        spacePos=surr_pos;
        nbrs = [];
        for levs = 0:0
            for oris = 0:pyr_oris
                for xpos = -spacePos/2:spacePos/2:spacePos/2
                    for ypos= -spacePos/2:spacePos/2:spacePos/2
                        if(xpos==ypos || xpos==-ypos)
                            xpos1 = round(xpos/sqrt(2));
                            ypos1 = round(ypos/sqrt(2));
                            nbrs = [nbrs; levs oris ypos1 xpos1];
                        else
                            nbrs = [nbrs; levs oris ypos xpos];
                        end
                    end
                end
            end
        end
    case('orisSquare')
        spacePos=surr_pos;
        nbrs = [];
        for levs = 0:0
            for oris = 0:pyr_oris
                for xpos = -spacePos/2:spacePos/2:spacePos/2
                    for ypos= -spacePos/2:spacePos/2:spacePos/2
                        nbrs = [nbrs; levs oris ypos xpos];
                    end
                end
            end
        end
    
    otherwise
        disp('**** write your own nbrs type')
end

%%
switch imset  
    case('images')
        for nim = 1:NIM
            im = squeeze(images(nim,:,:));
            % im = im.^2;
            im = (im-min(im(:))) / (max(im(:))-min(im(:)));

            [pyr,pind] = buildSCFpyr(im, pyr_height, pyr_oris,pyr_twid); % build pyramid
            nbReal = [MGSM_MULTISUR_revised_makeSnbrs(real(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - even phase
            nbImag = [MGSM_MULTISUR_revised_makeSnbrs(imag(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - odd phase
            oldneighbors = [nbReal, nbImag]; % quadrature pairs
            
            theCrop = spacePos*2; % need to crop the pyramid outputs to avoid edge artifacts; here we assume filter size is equal to filter spacing
            tmp = oldneighbors(:,1);
            thelen = sqrt(length(oldneighbors));
            tmp = reshape(tmp, thelen, thelen);
            tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
            tmp = tmp(:);
            newNeighbors = zeros(length(tmp), size(oldneighbors,2));
            for thei=1:size(oldneighbors,2) % collect all samples for 'thei'-th neighbor (position, ori, s.f., phase)
                tmp = oldneighbors(:,thei);
                thelen = sqrt(length(oldneighbors));
                tmp = reshape(tmp, thelen, thelen);
                tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
                newNeighbors(:,thei) = tmp(:);
            end
            
            if Nsamp>0 % subsample if required
                oneimNsamp = min([round(Nsamp/NIM) length(newNeighbors)]);
                tmpor = randperm(length(newNeighbors));
                newNeighbors=newNeighbors(tmpor(1:oneimNsamp),:);
            end
            neighbors = [neighbors; newNeighbors];
        end
        
    case('imagesRot') %% 4 rotated copies of each image, in steps of 45 deg
              for nim = 1:NIM
                  im = squeeze(images(nim,:,:));
                  % im = im.^2;
                  im = (im-min(im(:))) / (max(im(:))-min(im(:)));
                  imorig=im;
                  for rot=0:3
                      fprintf('Getting image%d samples...\n',nim);
                      im = imorig;
                      im = imrotate(im,rot*-45,'bilinear','crop'); % rotate the image
                      if(rot==0 || rot==2) % fake rotation, just so the blur introduced by 45deg rotations is similar for all 4 copies of the image
                          im = imrotate(im,-45,'bilinear','crop');
                          im = imrotate(im,45,'bilinear','crop');
                      end
                      
                      [pyr,pind] = buildSCFpyr(im, pyr_height, pyr_oris,pyr_twid); % build pyramid
                      nbReal = [MGSM_MULTISUR_revised_makeSnbrs(real(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - even phase
                      nbImag = [MGSM_MULTISUR_revised_makeSnbrs(imag(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - odd phase
                      oldneighbors = [nbReal, nbImag]; % quadrature pairs
                      clear nbReal nbImag pyr pind; % saving memory
                      
                      tmp = oldneighbors(:,1);
                      thelen = sqrt(length(oldneighbors));
                      tmp = reshape(tmp, thelen, thelen);
                      theCropRot = ceil((NP/2)*(1-1/sqrt(2)));% remove padding introduced by the 45deg rotation
                      tmp=tmp(theCropRot:end-theCropRot,theCropRot:end-theCropRot); % remove padding introduced by the 45deg rotation
                      thelen = size(tmp,1);
                      theCrop = spacePos*2;% need to crop the pyramid outputs to avoid edge artifacts; here I am assuming filter size is equal to filter spacing
                      tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
                      tmp = tmp(:);
                      newNeighbors = zeros(length(tmp), size(oldneighbors,2));
                      for thei=1:size(oldneighbors,2) % collect all samples for 'thei'-th neighbor (position, ori, s.f., phase)
                          tmp = oldneighbors(:,thei);
                          thelen = sqrt(length(oldneighbors));
                          tmp = reshape(tmp, thelen, thelen);
                          tmp = imrotate(tmp,rot*45,'bilinear','crop'); % rotate the map of filters' outputs back
                          tmp=tmp(theCropRot:end-theCropRot,theCropRot:end-theCropRot);
                          thelen = size(tmp,1);
                          tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
                          tmp = tmp(:);
                          newNeighbors(:,thei) = tmp;
                      end
                      
                      if Nsamp>0 % subsample if required
                          oneimNsamp = min([round(Nsamp/(4*NIM)) length(newNeighbors)]);
                          if(rot==0)
                              tmpor = randperm(length(newNeighbors));
                          end
                          newNeighbors=newNeighbors(tmpor(1:oneimNsamp),:);
                      end

                      neighbors = [neighbors; newNeighbors];
                      clear newNeighbors oldneighbors; 
                  end
              end
              
    case('imagesRotOne') %% rotate each image by 'rot' degrees
        for nim = 1:NIM
            im = squeeze(images(nim,:,:));
            % im = im.^2;
            im = (im-min(im(:))) / (max(im(:))-min(im(:)));
            im = imrotate(im,rotIn,'bilinear','crop'); % rotate the image
                
            [pyr,pind] = buildSCFpyr(im, pyr_height, pyr_oris,pyr_twid); % build pyramid
            nbReal = [MGSM_MULTISUR_revised_makeSnbrs(real(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - even phase
            nbImag = [MGSM_MULTISUR_revised_makeSnbrs(imag(pyr),pind,pyr_lev, nbrs)]; % extract filters outputs at desired positions, oris, s.f. - odd phase
            oldneighbors = [nbReal, nbImag]; % quadrature pairs
            clear nbReal nbImag pyr pind; % saving memory
            
            tmp = oldneighbors(:,1);
            thelen = sqrt(length(oldneighbors));
            tmp = reshape(tmp, thelen, thelen);
            theCropRot = ceil((NP/2)*(1-1/sqrt(2)));% remove padding introduced by the 45deg rotation
            tmp=tmp(theCropRot:end-theCropRot,theCropRot:end-theCropRot); % remove padding introduced by the 45deg rotation
            thelen = size(tmp,1);
            theCrop = spacePos*2;% need to crop the pyramid outputs to avoid edge artifacts; here I am assuming filter size is equal to filter spacing
            tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
            tmp = tmp(:);
            newNeighbors = zeros(length(tmp), size(oldneighbors,2));
            for thei=1:size(oldneighbors,2) % collect all samples for 'thei'-th neighbor (position, ori, s.f., phase)
                tmp = oldneighbors(:,thei);
                thelen = sqrt(length(oldneighbors));
                tmp = reshape(tmp, thelen, thelen);
                tmp=tmp(theCropRot:end-theCropRot,theCropRot:end-theCropRot);
                thelen = size(tmp,1);
                tmp = tmp(theCrop+1:thelen-theCrop, theCrop+1:thelen-theCrop);
                tmp = tmp(:);
                newNeighbors(:,thei) = tmp;
            end
            
            if Nsamp>0 % subsample if required
                oneimNsamp = min([round(Nsamp/NIM) length(newNeighbors)]);
                tmpor = randperm(length(newNeighbors));
                newNeighbors=newNeighbors(tmpor(1:oneimNsamp),:);
            end
                
            neighbors = [neighbors; newNeighbors];
            clear newNeighbors oldneighbors;
        end
    %%    
    otherwise
        disp('**** write your own imset type')
end

l=neighbors;

end

