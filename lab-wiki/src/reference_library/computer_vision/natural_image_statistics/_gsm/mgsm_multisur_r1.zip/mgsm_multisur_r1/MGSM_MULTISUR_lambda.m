function [lambdac,constc,lambdas,consts,lambdacs,constcs] = MGSM_MULTISUR_lambda(data,INVCOVc,INVCOVs,INVCOVcs,indc,inds,theeps)
% [lambdac,constc,lambdas,consts,lambdacs,constcs] = MGSM_MULTISUR_lambda(data,INVCOVc,INVCOVs,INVCOVcs,indc,inds,theeps)
%
%
% INPUTS
%   'data': [#samples x #filters]
%   'INVCOVc': [Kc x Kc] learned inverse covariance matrix between center filters
%   'INVCOVs': [#surrounds x #surround filters x #surround filters ] learned inverse covariance matrices
%           between surround filters, in each surround group
%   'INVCOVcs': [#surrounds x #center+surround filters  x #center+surround filters ] learned inverse covariance matrices
%           between all filters, in each center-surround group
%   'indc': [1 x #center filters  ] indices of center units
%   'inds': [#surrounds x #surround filters  ] indices of surround units
%   'theeps': small constant to prevent infinities in MGSM inference
%
% OUTPUTS
%   'lambdac': [1 x #datapoints] covariance-weighted center filters energy
%   'lambdas': [#surround groups x #datapoints] covariance-weighted surround filters energy
%   'lambdacs': [#surround groups x #datapoints] covariance-weighted center+surround filters energy
%   'constc': [scalar] useful normalization constant to perform MGSM inference
%   'consts': [#surround groups x 1] useful normalization constant to perform MGSM inference
%   'constcs': [#surround groups x 1] useful normalization constant to perform MGSM inference
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

if(~exist('theeps'))
    theeps=10^-10;
end
%%
NS = size(INVCOVs,1);
N = size(data,1);
lambdacs=NaN(NS,N); 
lambdas=NaN(NS,N); 
lambdac=NaN(1,N); 
constcs=NaN(NS,1);
consts=NaN(NS,1); 
constc = (sqrt(det(INVCOVc)));

for n = 1:N 
    lambdac(1,n) = sqrt(theeps + diag(data(n,indc) * INVCOVc * data(n,indc)'));
end
for i=1:NS
    tmpINVCOVcs = squeeze(INVCOVcs(i,:,:));
    constcs(i) = (sqrt(det(tmpINVCOVcs)));
    tmpINVCOVs = squeeze(INVCOVs(i,:,:));
    consts(i) = (sqrt(det(tmpINVCOVs)));
    for n = 1:N 
        lambdacs(i,n) = sqrt(theeps + diag(data(n,[indc inds(i,:)]) * tmpINVCOVcs * data(n,[indc inds(i,:)])'));
        lambdas(i,n) = sqrt(theeps + diag(data(n,inds(i,:)) * tmpINVCOVs * data(n,inds(i,:))'));
    end
end

