See file "crcns_mgsm-1_descrption.pdf"
available at:
http://dx.doi.org/10.6080/K0JM27JZ
for information about this software.
