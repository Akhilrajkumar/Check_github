function bands = MGSM_MULTISUR_revised_makeSnbrs(pyr,pind,lev,rnbrs)
% BANDS = MGSM_MULTISUR_revised_makeSnbrs(PYR, PIND, LEV, RNBRS)
%
% INPUTS
%   'pyr' and 'pind' are the pyramid data structure.
%   'rnbrs' should be an Nx4 matrix with columns giving RELATIVE scale, orientation, and [y,x]-position.  
%
% OUTPUTS
%   'bands' number of pixels x number of desired neighbors
% 
% NOTES
%   Orientations are calculated modulo the number of orientation bands.
%   [X,Y] positions are computed with reflection at boundaries.  
%   Bands outside the range [1,maxlev] are discarded.
%
%   Uses a number of routines from Eero Simoncelli's "Steerable pyramid toolbox"

%
% 2015 Ruben Coen-Cagli. 
% Adapted from older code by Odelia Schwartz, Martin Wainwright, Eero Simoncelli. 
%


%% taken from buildSFpyr.m:
if (exist('twidth') ~=1)
  twidth = 1;  
elseif (twidth <= 0)
  fprintf(1,'Warning: TWIDTH must be positive.  Setting to 1.\n');
  twidth = 1;
end

maxori = spyrNumBands(pind);
maxlev = spyrHt(pind);
bnum = 1+(lev-1)*maxori;
dims = pind(bnum,:);

rnbrs(:,1) = rnbrs(:,1) + lev;
rnbrs(:,2) = 1 + mod(rnbrs(:,2), maxori);

% Check level numbers in [1,maxlev]:
indices = find((rnbrs(:,1)>=1)&(rnbrs(:,1)<=maxlev));
rnbrs = rnbrs(indices , :);
nbrBnums = 1+maxori*(rnbrs(:,1)-1)+rnbrs(:,2);

%% Make cache matrix for bands
nbrBnums = unique(nbrBnums);
nbrBnums = [nbrBnums, zeros(size(nbrBnums,1),1)];
nbrBands = zeros([prod(dims), size(nbrBnums,1)]);

%% Taken from reconSFpyr.m:
if (any(rnbrs(:,1) > lev))
  ctr =   ceil((dims+0.5)/2);
  [xramp,yramp] = meshgrid( ([1:dims(2)]-ctr(2))./(dims(2)/2), ...
      ([1:dims(1)]-ctr(1))./(dims(1)/2) );
  angle = atan2(yramp,xramp);
  log_rad = sqrt(xramp.^2 + yramp.^2);
  log_rad(ctr(1),ctr(2)) =  log_rad(ctr(1),ctr(2)-1);
  log_rad  = log2(log_rad);
  [Xrcos,Yrcos] = rcosFn(twidth,(-twidth/2),[0 1]);
  Yrcos = sqrt(Yrcos);
end

bands = [];
for nnum = 1:size(rnbrs,1)
    nlev = rnbrs(nnum,1);
    nori = rnbrs(nnum,2);
    nbnum = 1+maxori*(nlev-1)+nori;
    nind = find(nbrBnums(:,1) == nbnum);
    if (prod(size(nind)) ~= 1)
        error('Busted');
    end
    
    if (nlev > lev)
        firstBand = max(2+maxori*(lev-1),1);
        firstInd = pyrBandIndices(pind,firstBand);
        
        % 1D interpolation filter
        interp = [-1/16 0 9/16 1 9/16 0 -1/16]/2;
        tmp = spyrBand(pyr, pind, nlev, nori);
        for k=1:(nlev-lev)
            tmp = upConv(tmp, interp, 'reflect1', [1 2], [1 1]);
            tmp = upConv(tmp, interp', 'reflect1', [2 1], [1 1]);
        end
        nbrBnums(nind,2) = 1;
        nbrBands(:,nind) = reshape(tmp,size(tmp,1)*size(tmp,2),1);
        
    elseif (nlev == lev)
        nbrBands(:,nind) = reshape(spyrBand(pyr, pind, nlev, nori),prod(dims),1);
        nbrBnums(nind,2) = 1;
    end
    
    mctr = abs(rnbrs(nnum,3:4))+1;
    if (any(mctr>1))
        msz = 2*mctr-1;
        interp = mkImpulse(msz,mctr-rnbrs(nnum,3:4));
        nband = reshape(corrDn(reshape(nbrBands(:,nind),dims), ...
            interp, 'circular'), prod(dims),1);
    else
        nband = nbrBands(:,nind);
    end
    
    bands = [bands,nband(:)];
end
