function [data, nbrsred, Kc, Ks, Kcs, indc, inds]= MGSM_MULTISUR_reduceNbrs(dataIN,nbrsIN,whichMGSM,surr_pos,mainOri)
% [data, nbrsred, Kc, Ks, Kcs, indc, inds]= MGSM_MULTISUR_reduceNbrs(dataIN,nbrsIN,whichMGSM,surr_pos,mainOri)
%
% INPUTS
%   'dataIN': filters outputs, [#samples  x#filters]
%   'nbrsIN': [#filters x 4], filters parameters {scale; orientation; y position; x position}
%         ***NOTE: y position is in 'image/matrix' coordinates; center = 0; up = negative; down = positive
%   'whichMGSM': which type of MGSM do we want to implement?
%   'surr_pos': controls the extent of the surround
%   'mainOri': optional; if it is a binary MGSM, what is the surround orientation?
%
% OUTPUTS
%   'data' and 'nbrsred' are the reduced versions of the corresponding inputs
%   'Kc', 'Ks', 'Kcs': how many filters in each group (center, surround, and center+surround)
%   'indc' and 'inds': indices of center and surround filters in 'data'

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

if ~exist('mainOri')
    mainOri=0;
end

%% initialize

data=dataIN;
nbrsred = nbrsIN;
Nori = numel(unique(nbrsIN(:,2)));

%%
switch whichMGSM
    case '5MGSM' %******** 5-MGSM, i.e. with 4 surround groups --- Coen-Cagli, Dayan, Schwartz PLoS Comp Biol 2012
        %%%%%%%%% keep only a subset of filters (only orientations 0,45,90,135) %%%
        indno = find(~ismember(nbrsIN(:,2),[0:Nori/4:(Nori-1)])); 
        data(:,[indno indno+length(nbrsIN)])=[];
        nbrsred(indno,:)=[];
        nbrsred(:,2) = nbrsred(:,2)/2;
        
        %%%%%%%%% number and indices of units %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Kc = 8;        % # center units [4 orientations x 2 phases]
        Ks1 = 16;      % # 'vertical surround' units [1 orientation x 8 positions x 2 phases]
        Ks2 = 16;      % # '+45 deg surround' units
        Ks3 = 16;      % # '0 deg surround' units
        Ks4 = 16;      % # '-45 deg surround' units
        Ks = [Ks1; Ks2; Ks3; Ks4];
        Kcs1 = Kc+Ks1;
        Kcs2 = Kc+Ks2;
        Kcs3 = Kc+Ks3;
        Kcs4 = Kc+Ks4;
        Kcs = [Kcs1; Kcs2; Kcs3; Kcs4];
        Ktot = Kc+Ks1+Ks2+Ks3+Ks4;
        indc = find(nbrsred(:,3)==0 & nbrsred(:,4)==0)'; % indices of center units, phase 1
        indc = [indc Ktot/2+indc];% indices of center units, phase 2
        inds1 = find(nbrsred(:,2)==0 & (nbrsred(:,3)~=0 | nbrsred(:,4)~=0))'; % indices of vert surr units, phase 1
        inds1 = [inds1 Ktot/2+inds1];% indices of vert surr units, phase 2
        inds2 = find(nbrsred(:,2)==1 & (nbrsred(:,3)~=0 | nbrsred(:,4)~=0))'; % indices of +45 surr units, phase 1
        inds2 = [inds2 Ktot/2+inds2];% indices of +45 surr units, phase 2
        inds3 = find(nbrsred(:,2)==2 & (nbrsred(:,3)~=0 | nbrsred(:,4)~=0))'; % indices of 0 surr units, phase 1
        inds3 = [inds3 Ktot/2+inds3];% indices of 0 surr units, phase 2
        inds4 = find(nbrsred(:,2)==3 & (nbrsred(:,3)~=0 | nbrsred(:,4)~=0))'; % indices of -45 surr units, phase 1
        inds4 = [inds4 Ktot/2+inds4];% indices of -45 surr units, phase 2
        inds = [inds1; inds2; inds3; inds4];
    case 'Binary' %********* binary MGSM, i.e. with 1 surround group --- Coen-Cagli, Dayan, Schwartz NIPS 2009
        %%%%%%%%% keep only a subset of filters (only orientations 0,45,90,135 in the center, only mainOri in the surround) %%%
        indno = find(~ismember(nbrsIN(:,2),[0:Nori/4:(Nori-1)])); 
        data(:,[indno indno+length(nbrsIN)])=[];
        nbrsred(indno,:)=[];
        nbrsred(:,2) = nbrsred(:,2)/2;
        indno = find((nbrsred(:,2)~=mainOri & (nbrsred(:,3)~=0 | nbrsred(:,4)~=0)) | abs(nbrsred(:,3))>surr_pos/2 | abs(nbrsred(:,4))>surr_pos/2);
        data(:,[indno indno+length(nbrsred)])=[];
        nbrsred(indno,:)=[];
        
        %%%%%%%%% number and indices of units %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Kc = 8;                                                    % # center units
        Ks = 16;                                                 % # surround units
        Kcs = Kc+Ks;                                                % # total units
        indc = find(nbrsred(:,3)==0 & nbrsred(:,4)==0)';      % indices of center units, phase 1
        indc = [indc Kcs/2+indc];% indices of center units, phase 2
        inds = find(nbrsred(:,3)~=0 | nbrsred(:,4)~=0)';      % indices of surround units, phase 1
        inds = [inds Kcs/2+inds];% indices of surround units, phase 2
        
    otherwise
        disp('**** write your own whichMGSM type')
end