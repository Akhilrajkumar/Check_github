function [LL DLL] = MGSM_MULTISUR_loglik_c(S,data,Q,loga,Kc,Ks,lPcs,indc,inds,theeps)
%   [LL DLL] = MGSM_MULTISUR_loglik_c(S,data,Q,loga,Kc,Ks,lPcs,indc,inds,theeps)
%   Expected Negative LogLikelihood (of the covriance matrix, given the current assignment) and its gradient, in the MGSM.
%
% INPUTS
%   'S': covariance matrices for the center alone and surround alone configurations, all in one long vector
%   'data': [#samples x #filters]
%   'Q': [(1 + #surrounds) x #datapoints] posterior probability of the un-assigned component (first entry) 
%           and the assigned components for each surround group
%   'loga': [(1 + #surrounds) x 1] log-prior probability
%   'Kc': #filters in the center
%   'Ks': [#surrounds x 1] #filters in each surround group
%   'lPcs': [#surrounds x #datapoints] log-lik of the assigned center+surround configurations
%   'indc': [1 x Kc] indices of center units
%   'inds': [#surrounds x Ks(1)] indices of surround units
%   'theeps': small constant to prevent infinities in MGSM inference
%
% OUTPUTS
%   'LL': negative log-likelihood 
%   'DLL': vector of derivatives w.r.t. the entries of the covariance matrix 
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%
%   Expected Negative LogLikelihood and its gradient, of the covriance matrix in the MGSM.
%   It returns the LogLikelihood (LL) and
%   its gradient (DLL) wrt to the parameters S, as a (K*K,1) vector.
%   Uses the chain rule to get dL/dS = dL/dINVCOV * dINVCOV/dCOV * dCOV/dS
%

%% warning
if(any(isnan(S)))
    fprintf('\n\n NaN params from minimize to MGSM_MULTISUR_loglik_c\n\n');
end

%% PARSE INPUTS
N = size(data,1);   % # of samples
NS = numel(loga)-1;    % # of surround groups

Sc = reshape(S(1:Kc*Kc),Kc,Kc);
COVc = Sc*Sc' ;
INVCOVc = COVc\eye(Kc,Kc); 

Ss = NaN(NS,Ks(1),Ks(1));
COVs = NaN(NS,Ks(1),Ks(1));
INVCOVs = COVs;
for i=1:NS
    tmpSs = reshape(S(Kc*Kc+(Ks(i)*Ks(i))*(i-1)+(1:Ks(i)*Ks(i))),Ks(i),Ks(i));
    Ss(i,:,:) = tmpSs;
    tmpC = tmpSs*tmpSs';
    COVs(i,:,:) = tmpC;
    INVCOVs(i,:,:) = tmpC\eye(Ks(i),Ks(i));
end

%% COMPUTE LOGLIK 'LL'

l2pi = log(2*pi);
lambdac=NaN(1,N);
lambdas=NaN(NS,N);
consts=NaN(NS,1);
b1s=NaN(NS,N);
b2s=NaN(NS,N);
lPs=NaN(NS,N);
lP=NaN(NS+1,N);
QL=NaN(NS+1,N);

%************ note here we are updating the inputs 'constc', 'consts', 'lambdac' and 'lambdas' based on the new parameter values
%%%%%% minibatches of 100 to save 60% time
constc = (sqrt(det(INVCOVc)));
for i=1:NS
    tmpINVCOVs = squeeze(INVCOVs(i,:,:));
    consts(i) = (sqrt(det(tmpINVCOVs)));
    for m = 1:size(data,1)/100
        n =((m-1)*100+1):m*100;              
        lambdac(n) = sqrt(theeps + diag(data(n,indc) * INVCOVc * data(n,indc)'));
        lambdas(i,n) = sqrt(theeps + diag(data(n,inds(i,:)) * tmpINVCOVs * data(n,inds(i,:))'));
    end
end
%************

b1c = besselk(-(Kc)/2 , lambdac) + eps;
b2c = besselk(-(Kc-2)/2 , lambdac) + eps;
for i=1:NS
    b1s(i,:) = besselk(-(Ks(i))/2 , lambdas(i,:)) + eps;
    b2s(i,:) = besselk(-(Ks(i)-2)/2 , lambdas(i,:)) + eps;
end

lPc = log(constc) + log(b2c) - ((Kc-2)/2)*log(lambdac) - (Kc/2)*l2pi;
for i=1:NS
    lPs(i,:) = log(consts(i)) + log(b2s(i,:)) - ((Ks(i)-2)/2)*log(lambdas(i,:)) - (Ks(i)/2)*l2pi;
end

lP(1,:) = lPc+nansum(lPs,1);
for i=1:NS
    inot = 1:NS;
    inot(inot==i)=[];
    lP(i+1,:) = lPcs(i,:) + nansum(lPs(inot,:),1);
end

for i=1:NS+1
    tmp = loga(i)+lP(i,:);
    QL(i,:) = Q(i,:).*tmp;
end

indno = (sum(~isfinite(QL),1)>0);
indn = 1:N;
indn(indno) = [];
if(sum(indno)>0)
    fprintf('%d nan or inf in MGSM_MULTISUR_loglik_c \n',sum(indno));
end

QL(:,indno)=[];
LL = -squeeze(sum(mean(QL,2),1));


%% compute gradient 'DLL'
basec = ((Q(1,:).*b1c)./(b2c.*(lambdac)))'; 
basec(indno)=[]; 
DLc = - 0.5 * ( ((repmat(basec,[1 Kc])'.*data(indn,indc)')...
    *data(indn,indc))/length(indn) - nanmean(Q(1,indn))*COVc);           % the matrix derivative of L wrt INVCOVcs
DLLc = (INVCOVc'*DLc*INVCOVc')*Sc + (INVCOVc*DLc'*INVCOVc)*Sc; % the matrix derivative of L wrt S
DLLc = -DLLc;
DLLc = reshape(DLLc,Kc*Kc,1);

DLLs = NaN(Ks(1)*Ks(1),NS);
for i=1:NS
    tmpINVCOVs = squeeze(INVCOVs(i,:,:));
    tmpSs = squeeze(Ss(i,:,:));
    inot = 1:NS;
    inot(inot==i)=[];
    bases = ( ((Q(1,:)+nansum(Q(1+inot,:),1)).*b1s(i,:))./(b2s(i,:).*(lambdas(i,:))) )'; 
    bases(indno)=[];
    DLs = - 0.5 * ( ((repmat(bases,[1 Ks(i)])'.*data(indn,inds(i,:))')...
        *data(indn,inds(i,:)))/length(indn) - (nansum(nanmean(Q([1 (1+inot)],indn),2),1))*squeeze(COVs(i,:,:)));           % the matrix derivative of L wrt INVCOVcs
    tmpDLLs = (tmpINVCOVs'*DLs*tmpINVCOVs')*tmpSs + (tmpINVCOVs*DLs'*tmpINVCOVs)*tmpSs; % the matrix derivative of L wrt S
    tmpDLLs = -tmpDLLs;
    DLLs(:,i) = reshape(tmpDLLs,Ks(i)*Ks(i),1);
end
DLL = -[DLLc; reshape(DLLs,NS*Ks(1)*Ks(1),1)];

end
