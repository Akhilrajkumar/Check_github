function Q = MGSM_MULTISUR_posteriorAssign(loga,lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs)
% Q = MGSM_MULTISUR_posteriorAssign(loga,lambdac,constc,Kc,lambdas,consts,Ks,lambdacs,constcs,Kcs)
% Compute posterior assignment probability
%
% INPUTS
%   'loga': [(1 + #surrounds) x 1] log-prior probability
%   'lambdac': [1 x #datapoints] covariance-weighted center filters energy
%   'lambdas': [#surround groups x #datapoints] covariance-weighted surround filters energy
%   'lambdacs': [#surround groups x #datapoints] covariance-weighted center+surround filters energy
%   'constc': [scalar] useful normalization constant to perform MGSM inference
%   'consts': [#surround groups x 1] useful normalization constant to perform MGSM inference
%   'constcs': [#surround groups x 1] useful normalization constant to perform MGSM inference
%   'Kc': #filters in the center
%   'Ks': [#surrounds x 1] #filters in each surround group
%   'Kcs': [#surrounds x 1] total #filters (center plus surround) in each group
%
% OUTPUTS
%   'Q': [(1 + #surrounds) x #datapoints] posterior probability of the
%   un-assigned component (first entry) and the assigned components for
%   each surround group
%

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%%
[NS, N] = size(lambdacs);
l2pi = log(2*pi);
b2s=NaN(NS,N);
b2cs=NaN(NS,N);
lPs=NaN(NS,N);
lPcs=NaN(NS,N);
lP=NaN(NS+1,N);

b2c = besselk(-(Kc-2)/2 , lambdac);
for i=1:NS
    b2s(i,:) = besselk(-(Ks(i)-2)/2 , lambdas(i,:));
    b2cs(i,:) = besselk(-(Kcs(i)-2)/2 , lambdacs(i,:));
end

lPc = log(constc) + log(b2c) - ((Kc-2)/2)*log(lambdac) - (Kc/2)*l2pi;
for i=1:NS
    lPcs(i,:) = log(constcs(i)) + log(b2cs(i,:)) - ((Kcs(i)-2)/2)*log(lambdacs(i,:)) - (Kcs(i)/2)*l2pi;
    lPs(i,:) = log(consts(i)) + log(b2s(i,:)) - ((Ks(i)-2)/2)*log(lambdas(i,:)) - (Ks(i)/2)*l2pi;
end

lP(1,:) = lPc+nansum(lPs,1);
for i=1:NS
    inot = 1:NS;
    inot(inot==i)=[];
    lP(i+1,:) = lPcs(i,:) + nansum(lPs(inot,:),1);
end

logaN = repmat(loga(:),1,N);
laP = logaN + lP;
aP = exp(laP);
denom = nansum(aP,1);
Q = aP ./ repmat(denom,NS+1,1);

end
