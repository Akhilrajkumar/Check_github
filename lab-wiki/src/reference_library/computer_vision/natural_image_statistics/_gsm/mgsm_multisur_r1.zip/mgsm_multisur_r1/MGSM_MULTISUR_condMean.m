function [M, S, Y, X] =  MGSM_MULTISUR_condMean(Yim, Xim, nbins)
% [M, S, Y, X] =  MGSM_MULTISUR_condMean(Yim, Xim, nbins)
% Conditional mean and standard deviation

% 2015 Ruben Coen-Cagli 
% Adapted from Eero Simoncelli, Spring 97.

if (exist('nbins') == 1) 
  nbins = abs(round(nbins));
  if (prod(size(nbins)) == 1)
    nbins = [nbins,nbins];
  else
    nbins = nbins(:);
  end
else
  nbins = [101, 101]';
end

%%
nbins=nbins-1;
[Xmn, Xmx] = range2(Xim);
X = Xmn + (Xmx-Xmn)*[0:nbins(2)]/nbins(2);
[Ymn, Ymx] = range2(Yim);
Y = Ymn + (Ymx-Ymn)*[0:nbins(1)]/nbins(1);
Ybs = (Y(2)-Y(1))/2;
Xbs = (X(2)-X(1))/2;
nbins=nbins+1;
M = zeros(nbins(2),1);
S = zeros(nbins(2),1);
for xind=1:nbins(2)
  ind1 = find(Xim > (X(xind)-Xbs));
  ind2 = find(Xim(ind1) < (X(xind)+Xbs));
  ind = ind1(ind2);
  if(size(ind,2)>0)
      M(xind) = mean(Yim(ind));
    S(xind) = std(Yim(ind));
  end
end


