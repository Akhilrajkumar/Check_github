function LL = MGSM_MULTISUR_loglik(data,Q,loga,Kc,Ks,Kcs,lambdac,constc,lambdas,consts,lambdacs,constcs)
%   LL = MGSM_MULTISUR_loglik (data,Q,loga,Kc,Ks,Kcs,lambdac,constc,lambdas,consts,lambdacs,constcs)
%   Expected Negative LogLikelihood (of the covriance matrix, given the current assignment) in the MGSM.
%
% INPUTS
%   'data': [#samples x #filters]
%   'Q': [(1 + #surrounds) x #datapoints] posterior probability of the un-assigned component (first entry) 
%           and the assigned components for each surround group
%   'loga': [(1 + #surrounds) x 1] log-prior probability
%   'Kc': #filters in the center
%   'Ks': [#surrounds x 1] #filters in each surround group
%   'Kcs': [#surrounds x 1] total #filters (center plus surround) in each group
%   'lambdac': [1 x #datapoints] covariance-weighted center filters energy
%   'lambdas': [#surround groups x #datapoints] covariance-weighted surround filters energy
%   'lambdacs': [#surround groups x #datapoints] covariance-weighted center+surround filters energy
%   'constc': [scalar] useful normalization constant to perform MGSM inference
%   'consts': [#surround groups x 1] useful normalization constant to perform MGSM inference
%   'constcs': [#surround groups x 1] useful normalization constant to perform MGSM inference
%
% OUTPUTS
%   'LL': negative log-likelihood 

%
% Copyright (c) 2015, Ruben Coen-Cagli. 
% All rights reserved.
% See the file LICENSE for licensing information.
%
% Based on:
% Coen-Cagli, Dayan, Schwartz. "Cortical Surround Interactions and Perceptual Salience via Natural Scene Statistics". 
% PLoS Comp Biol 2012. DOI: 10.1371/journal.pcbi.1002405
%

%% PARSE INPUTS
N = size(data,1);   % # of samples
NS = numel(loga)-1;    % # of surround groups

%% COMPUTE LOGLIK 'LL'

l2pi = log(2*pi);
b1s=NaN(NS,N);
b2s=NaN(NS,N);
b2cs=NaN(NS,N);
lPs=NaN(NS,N);
lPcs=NaN(NS,N);
lP=NaN(NS+1,N);
QL=NaN(NS+1,N);

b2c = besselk(-(Kc-2)/2 , lambdac);
for i=1:NS
    b1s(i,:) = besselk(-(Ks(i))/2 , lambdas(i,:));
    b2s(i,:) = besselk(-(Ks(i)-2)/2 , lambdas(i,:));
    b2cs(i,:) = besselk(-(Kcs(i)-2)/2 , lambdacs(i,:));
end

lPc = log(constc) + log(b2c) - ((Kc-2)/2)*log(lambdac) - (Kc/2)*l2pi;
for i=1:NS
    lPcs(i,:) = log(constcs(i)) + log(b2cs(i,:)) - ((Kcs(i)-2)/2)*log(lambdacs(i,:)) - (Kcs(i)/2)*l2pi;
    lPs(i,:) = log(consts(i)) + log(b2s(i,:)) - ((Ks(i)-2)/2)*log(lambdas(i,:)) - (Ks(i)/2)*l2pi;
end

lP(1,:) = lPc+nansum(lPs,1);
for i=1:NS
    inot = 1:NS;
    inot(inot==i)=[];
    lP(i+1,:) = lPcs(i,:) + nansum(lPs(inot,:),1);
end

for i=1:NS+1
    tmp = loga(i)+lP(i,:);
    QL(i,:) = Q(i,:).*tmp;
end

indno = (sum(~isfinite(QL),1)>0);
if(sum(indno)>0)
    fprintf('%d nan or inf in MGSM_MULTISUR_loglik \n',sum(indno));
end

QL(:,indno)=[];
LL = -squeeze(sum(mean(QL,2),1));


end
